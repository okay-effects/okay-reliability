package okay.reliability

import okay.effects.time.Instant

/**
 * A DETERMINISTIC READER OF LOGS AND CHAT (spec §5): the facts in the common lines — a call refused, a
 * status 5xx, a timeout, stale data served, a fallback used, a feature degraded, a disk full, a backlog, a slow query,
 * an unhandled exception — in JSON lines, logfmt, plain text and access logs; a component whose log says nothing wrong
 * is healthy. Names are the system's. What it does not recognize it leaves to a model (MCP `assert`).
 */
object Read:
  private val field = """"?(?:msg|message)"?\s*[:=]\s*"((?:[^"\\]|\\.)*)"""".r
  private val pinoLevel = """"level"\s*:\s*(\d{2})""".r
  private val errorField = """"(?:error|err)"\s*:\s*"((?:[^"\\]|\\.)*)"""".r
  private val levelField = """"?(?:level|severity)"?\s*[:=]\s*"?([A-Za-z]+)""".r
  private val plain = """^\S+\s+(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL)\s+(?:\[[^\]]*\]\s+)?(.*)$""".r
  private val access = """"[A-Z]+ [^"]*" (\d{3}) """.r
  private val name = "([A-Za-z0-9_.-]+)"
  private val refused = (s"call to $name failed: connection refused").r.unanchored
  private val refused2 = (s"(?i)(?:connect(?:ion)? to $name (?:refused|failed)|$name: connection refused)").r.unanchored
  private val status5 = (s"(?i)call to $name failed: status (5\\d\\d)").r.unanchored
  private val status5b = (s"(?i)$name returned (?:status )?(5\\d\\d)").r.unanchored
  private val timeout = (s"(?i)call to $name timed out").r.unanchored
  private val timeout2 = (s"(?i)timeout (?:calling|waiting for) $name").r.unanchored
  private val stale = (s"(?i)$name unavailable, serving cached").r.unanchored
  private val fallback = (s"(?i)$name failing, using fallback").r.unanchored
  private val degraded = (s"(?i)$name unavailable, feature degraded").r.unanchored
  private val changeLine = ("(?i)(deployed version \\S+|deploying version|Started \\S+ in [0-9.]+ seconds|" +
    "Scaled up replica set|rollout (started|complete)|new version \\S+ (is )?live)").r.unanchored
  private val configLine = "(?i)(configuration reloaded|config(uration)? (changed|updated|reloaded))".r.unanchored
  private val piling = (s"(?i)messages for $name piling up").r.unanchored

  /** a line's level and message, whatever its format; None for a stack trace's line */
  def parse(line: String): Option[(String, String)] =
    val l = line.trim
    if l.isEmpty || l.startsWith("at ") || l.startsWith("\tat") || l.startsWith("Caused by") ||
      l.matches("""^[a-z]+(\.[a-zA-Z_$][\w$]*)+(Exception|Error)(:.*)?$""") then None
    else
      field.findFirstMatchIn(l) match
        case Some(m) =>
          val msg = m.group(1).replace("\\\"", "\"").replace("\\\\", "\\")
          val level = levelField.findFirstMatchIn(l).map(_.group(1).toUpperCase).orElse(pinoLevel.findFirstMatchIn(l)
            .map(m => m.group(1).toInt match
              case n if n >= 50 => "ERROR"
              case n if n >= 40 => "WARN"
              case _ => "INFO")).orElse(access.findFirstMatchIn(l)
            .map(a => if a.group(1).startsWith("5") then "ERROR" else "INFO")).getOrElse("INFO")
          val error = errorField.findFirstMatchIn(l).map(e => ": " + e.group(1)).getOrElse("")
          Some(level -> (msg + error))
        case None => l match
          case plain(level, msg) => Some(level.toUpperCase.replace("WARNING", "WARN") -> msg)
          case _ => access.findFirstMatchIn(l) match
              case Some(a) => Some((if a.group(1).startsWith("5") then "ERROR" else "INFO") -> s"status ${a.group(1)}")
              case None => Some("INFO" -> l)

  def time(line: String): Option[Long] = Instant.find(line).map(_.seconds)

  // ---- THE USUAL STACKS (spec §21)

  private val urlHost = """(?i)https?://([A-Za-z0-9_.-]+)""".r
  private val envoyCluster = """outbound\|\d*\|[^|]*\|([A-Za-z0-9_-]+)""".r
  private val envoyLine = """"[A-Z]+ [^"]*" (\d{3}) ([A-Z,]+|-) """.r
  private val envoyUpstream = """"([A-Za-z][A-Za-z0-9_.-]*):\d+"""".r
  private val notFound = """(?i)(?:getaddrinfo ENOTFOUND|lookup) ([A-Za-z0-9_.-]+)""".r
  private val dialHost = """(?i)dial tcp ([A-Za-z][A-Za-z0-9_.-]*):\d+""".r
  private val redisTo = """(?i)redis connection to ([A-Za-z][A-Za-z0-9_.-]*):\d+""".r
  private val pgDuration = """(?i)duration: ([0-9.]+) ms\s+(?:statement|execute)""".r

  /** a host's component: its first label, if the system has it */
  private def named(system: System, host: String): Option[String] =
    Option(host.split('.').head).filter(system.names.contains)

  /** the callee a line names: a URL's host, an Envoy cluster or upstream, a lookup, a dial */
  def calleeIn(system: System, line: String): Option[String] =
    (envoyCluster.findFirstMatchIn(line) ++ urlHost.findAllMatchIn(line) ++ notFound.findFirstMatchIn(line) ++
      dialHost.findFirstMatchIn(line) ++ redisTo.findFirstMatchIn(line) ++ envoyUpstream.findAllMatchIn(line))
      .flatMap(m => named(system, m.group(1))).headOption

  /** the only database `c` calls, if it calls one: what a pool's timeout is about */
  private def itsDatabase(system: System, c: String): Option[String] =
    system.callees(c).map(_.to).filter(n => system.component(n).exists(_.kind == Kind.Database)) match
      case Vector(one) => Some(one)
      case _ => None

  /** THE FACTS OF A LINE OF THE USUAL STACKS, before the message's own: whole lines (an access log, nginx's error
   * log, Postgres) and the phrases of Java, Node and Go clients */
  def stackFacts(system: System, c: String, line: String): Option[Vector[Observation]] =
    import EffectKind.*
    val callee = calleeIn(system, line)
    def calleeAs(k: EffectKind) = callee.filter(_ != c).toVector.map(S(_, k))
    val l = line.toLowerCase
    envoyLine.findFirstMatchIn(line).filter(m => m.group(2) != "-") match
      case Some(m) =>
        val flags = m.group(2).split(",").toSet
        if flags("UF") || flags("UH") then Some(S(c, Errors) +: calleeAs(Down))
        else if flags("UT") then Some(S(c, Slow) +: calleeAs(Slow))
        else if flags("UO") || flags("URX") then Some(Vector(S(c, Errors)))
        else None
      case None =>
        if l.contains("while connecting to upstream") && l.contains("connection refused") then
          Some(S(c, Errors) +: calleeAs(Down))
        else if l.contains("upstream timed out") then Some(S(c, Slow) +: calleeAs(Slow))
        else if l.contains("too many clients already") then Some(Vector(S(c, Errors)))
        else if l.contains("database system is shutting down") || l.contains("database system is starting up") ||
          l.contains("in recovery mode") then Some(Vector(S(c, Errors)))
        else if pgDuration.findFirstMatchIn(line).exists(_.group(1).toDouble >= 1000) then Some(Vector(S(c, Slow)))
        else if l.contains("connection is not available, request timed out") then
          Some(S(c, Slow) +: itsDatabase(system, c).toVector.map(S(_, Slow)))
        else if l.contains("enotfound") || l.contains("no such host") then Some(S(c, Errors) +: calleeAs(Down))
        else if l.contains("connection refused") || l.contains("econnrefused") then
          Some(S(c, Errors) +: calleeAs(Down))
        else if l.contains("read timed out") || l.contains("sockettimeoutexception") || l.contains("etimedout") ||
          l.contains("context deadline exceeded") || l.contains("i/o timeout") then Some(S(c, Slow) +: calleeAs(Slow))
        else None

  private def S(c: String, k: EffectKind) = Observation.Symptom(c, k)

  /** the facts of one message of `c`, the names checked against the system */
  def facts(system: System, c: String, level: String, msg: String, raw: String = ""): Vector[Observation] =
    import EffectKind.*
    val known = system.names.toSet
    def callee(n: String, k: EffectKind) = if known(n) then Vector(S(n, k)) else Vector.empty
    def alive(n: String) = if known(n) then Vector(Observation.Alive(n)) else Vector.empty
    msg match
      case refused(x) => S(c, Errors) +: callee(x, Down)
      case refused2(a, b) if known(Option(a).getOrElse(b)) => S(c, Errors) +: callee(Option(a).getOrElse(b), Down)
      // a status returned: the callee answered — alive, not down
      case status5(x, code) => (S(c, if code == "504" then Slow else Errors) +: callee(x, if code == "504" then Slow
        else Errors)) ++ alive(x)
      case status5b(x, code) => (S(c, if code == "504" then Slow else Errors) +: callee(x, if code == "504" then Slow
        else Errors)) ++ alive(x)
      case timeout(x) => S(c, Slow) +: callee(x, Slow)
      case timeout2(x) => S(c, Slow) +: callee(x, Slow)
      case stale(_) => Vector(S(c, Stale))
      case fallback(_) => Vector(S(c, Retries))
      case degraded(_) => Vector(S(c, Retries))
      case piling(_) => Vector(S(c, Backlog))
      case changeLine(_*) => Vector(Observation.Changed(c, "deploy"))
      case configLine(_*) => Vector(Observation.Changed(c, "config"))
      case m if m.contains("No space left on device") => Vector(S(c, Errors))
      case m if m.toLowerCase.contains("backlog growing") => Vector(S(c, Backlog))
      case m if m.toLowerCase.startsWith("slow query") || m.matches("""(?i)request took \d+ms.*""") =>
        Vector(S(c, Slow))
      case m if m.toLowerCase.contains("not responding to health checks") => Vector(S(c, Retries))
      // the usual stacks' lines, whole: before a status alone and a level alone, which say less
      case _ if stackFacts(system, c, if raw.nonEmpty then raw else msg).nonEmpty =>
        stackFacts(system, c, if raw.nonEmpty then raw else msg).get
      case m if m.matches("""status 50[234]""") => Vector(S(c, if m.endsWith("504") then Slow else Errors))
      case _ if level == "ERROR" || level == "FATAL" => Vector(S(c, Errors))
      case _ => Vector.empty

  /** a component's log: its facts, each with its line; healthy when it says nothing wrong */
  def log(system: System, c: String, lines: Vector[String]): Vector[Observation] =
    val found = lines.zipWithIndex.flatMap((l, i) => parse(l).toVector.flatMap((level, msg) =>
      facts(system, c, level, msg, l).map {
        case Observation.Symptom(x, k, _, _) => Observation.Symptom(x, k, s"log:$c:${i + 1}", time(l))
        case Observation.Alive(x, _) => Observation.Alive(x, s"log:$c:${i + 1}")
        case Observation.Changed(x, w, _, _) => Observation.Changed(x, w, s"log:$c:${i + 1}", time(l))
        case h => h
      }))
    if !lines.exists(_.trim.nonEmpty) then found
    // healthy: no symptom in it (a change said is no symptom)
    else Observation.Alive(c, s"log:$c") +: (if found.exists(_.isInstanceOf[Observation.Symptom]) then found
      else found :+ Observation.Healthy(c, s"log:$c"))

  private val good = "(?i)(works fine|working fine|is fine|is ok|работает нормально|работает|в порядке)".r.unanchored
  private val failing = "(?i)(failing|errors?|down|падает|ошибк|не работает)".r.unanchored
  private val slowly = "(?i)(very slow|slow|медленно|тормозит)".r.unanchored

  /** a chat's lines: a component named, and what is said of it */
  def chat(system: System, lines: Vector[String]): Vector[Observation] =
    lines.zipWithIndex.flatMap { (l, i) =>
      val src = s"chat:${i + 1}"
      val named = system.names.filter(n => mentions(l, n))
      named.flatMap { n =>
        if slowly.findFirstIn(l).isDefined then Vector(Observation.Symptom(n, EffectKind.Slow, src))
        else if failing.findFirstIn(l).isDefined && !l.contains("не работает нормально") then
          Vector(Observation.Symptom(n, EffectKind.Errors, src))
        else if good.findFirstIn(l).isDefined then Vector(Observation.Healthy(n, src))
        else Vector.empty
      }
    }

  /** whether a line names a component: the name, not inside a longer one */
  def mentions(line: String, name: String): Boolean =
    def part(c: Char) = c.isLetterOrDigit || c == '_' || c == '-'
    var i = line.indexOf(name)
    var found = false
    while i >= 0 && !found do
      val before = i == 0 || !part(line.charAt(i - 1))
      val after = i + name.length >= line.length || !part(line.charAt(i + name.length))
      if before && after then found = true else i = line.indexOf(name, i + 1)
    found

  /** all of them, each kind of fact once (its first source) */
  def all(system: System, logs: Map[String, Vector[String]], chatLines: Vector[String]): Vector[Observation] =
    (logs.toVector.sortBy(_._1).flatMap((c, ls) => log(system, c, ls)) ++ chat(system, chatLines))
      .distinctBy(o => (o.productPrefix, o.component, o match
        case Observation.Symptom(_, k, _, _) => k.word
        case Observation.Changed(_, w, _, at) => s"$w$at"
        case _ => ""))
